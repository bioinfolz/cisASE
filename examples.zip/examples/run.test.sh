###run cisASE with DNA.pileup (recommended)
### turning off simulation by -S 0
perl ./cisASE.pl SNV -L SNV.list.txt -X RNA.pileup -Y DNA.pileup -o SNV.test.txt -F 33 -f 64 -d 10 -S 0
perl ./cisASE.pl EXON -N Annotation.txt -L SNV.list.txt -X RNA.pileup -Y DNA.pileup -o EXON.test.txt -F 33 -f 64 -d 10 -S 0
perl ./cisASE.pl GENE -N Annotation.txt -L SNV.list.txt -X RNA.pileup -Y DNA.pileup -o GENE.test.txt  -F 33 -f 64 -d 10  -S 0 
perl ./cisASE.pl GENE -P phased.txt -N Annotation.txt -L SNV.list.txt -X RNA.pileup -Y DNA.pileup -o GENE.phased.test.txt  -F 33 -f 64 -d 10 -S 0 

###run cisASE with simulation turning on (recommended)
#perl ./cisASE.pl GENE -P phased.txt -N Annotation.txt -L SNV.list.txt -X RNA.pileup -Y DNA.pileup -o GENE.phased.test.3.txt  -F 33 -f 64 -d 10 


###run cisASE without DNA.pileup, and set DNA bias as -B 0.5.
perl ./cisASE.pl SNV -L SNV.list.txt -X RNA.pileup  -o SNV.test2.txt -F 33 -f 64 -d 10 -B 0.5 -S 0
perl ./cisASE.pl EXON -N Annotation.txt -L SNV.list.txt -X RNA.pileup -o EXON.test2.txt -B 0.5 -F 33 -f 64 -d 10 -S 0
perl ./cisASE.pl GENE -N Annotation.txt -L SNV.list.txt -X RNA.pileup -o GENE.test2.txt  -B 0.5 -F 33 -f 64 -d 10  -S 0
perl ./cisASE.pl GENE -P phased.txt -N Annotation.txt -L SNV.list.txt -X RNA.pileup  -o GENE.phased.test2.txt  -B 0.5 -F 33 -f 64 -d 10 -S 0

